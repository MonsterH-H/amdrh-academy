# Académie AMDRH — Plateforme e-learning Handball

## 🏐 À propos

Plateforme de formation en ligne de l'Association Marocaine Des Arbitres de Handball (AMDRH), partenaire académique officiel de la FRMHB.

## 🚀 Installation

### Prérequis
- **Node.js** >= 18
- **npm** ou **bun**

### Étapes

```bash
# 1. Installer les dépendances
npm install
# ou: bun install

# 2. Configurer l'environnement
cp .env.example .env
# Éditez .env et remplacez NEXTAUTH_SECRET par une clé sécurisée
# Pour générer: openssl rand -base64 32

# 3. Initialiser la base de données
npx prisma db push
npx prisma db seed

# 4. Lancer le serveur de développement
npm run dev
# ou: bun run dev
```

L'application est accessible sur **http://localhost:3000**

## 👥 Rôles

| Rôle | Description |
|------|-------------|
| ADMIN | Administration complète de la plateforme |
| FORMATEUR | Création et gestion des cours et quiz |
| ARBITRE | Formation à l'arbitrage handball |
| ENTRAINEUR | Formation à l'entraînement |
| JOUEUR | Formation aux techniques de jeu |

## 🏗️ Architecture

```
src/
├── app/              # Next.js App Router (routes + API)
│   ├── page.tsx      # Point d'entrée principal
│   ├── proxy.ts      # Middleware d'authentification
│   └── api/          # 50 routes API REST
├── modules/          # Modules fonctionnels (feature-based)
│   ├── auth/         # Authentification
│   ├── courses/      # Cours et catalogue
│   ├── quiz/         # Quiz et évaluations
│   ├── certificates/ # Certificats et badges
│   ├── messages/     # Messagerie temps réel
│   ├── notifications/# Notifications
│   ├── learning-paths/# Parcours de formation
│   ├── profile/      # Profil utilisateur
│   ├── learner/      # Espace apprenant
│   ├── admin/        # Administration
│   ├── landing/      # Page d'accueil
│   └── shared/       # Layout partagé
├── components/ui/    # Composants shadcn/ui
├── services/         # Couche API client
├── store/            # État global (Zustand)
├── types/            # Types TypeScript
├── utils/            # Utilitaires
├── hooks/            # Hooks personnalisés
└── lib/              # Configuration (DB, Auth)
```

## 🛠️ Technologies

- **Next.js 16** (App Router)
- **TypeScript 5**
- **Tailwind CSS 4** + **shadcn/ui**
- **Prisma ORM** + **SQLite**
- **NextAuth.js v5** (JWT)
- **Zustand** (état client)
- **Recharts** (graphiques)
- **Lucide React** (icônes)

## 📦 Scripts

```bash
npm run dev          # Serveur de développement
npm run lint         # Vérification ESLint
npm run db:push      # Pousser le schéma Prisma
npm run db:seed      # Peupler la base de données
npm run db:studio    # Ouvrir Prisma Studio
```

## 📄 Licence

Propriétaire — AMDRH
