import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
const BADGE_LEVELS = ["BRONZE", "ARGENT", "OR", "PLATINE"] as const;
import { requireRole } from "@/lib/auth-helpers";

// GET /api/admin/badges — list all badges with earned count
export async function GET(req: NextRequest) {
  try {
    const auth = await requireRole(req, ["ADMIN"]);
    if (!auth.authorized) return auth.response;
    const badges = await db.badge.findMany({
      include: {
        _count: {
          select: { userBadges: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ badges });
  } catch (error) {
    console.error("Admin badges GET error:", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}

// POST /api/admin/badges — create new badge
export async function POST(req: NextRequest) {
  try {
    const auth = await requireRole(req, ["ADMIN"]);
    if (!auth.authorized) return auth.response;
    const body = await req.json();
    const { name, description, level, icon, criteria, points } = body;

    if (!name || !description || !level) {
      return NextResponse.json(
        { error: "name, description et level sont requis" },
        { status: 400 }
      );
    }

    // Validate level
    if (!BADGE_LEVELS.includes(level as typeof BADGE_LEVELS[number])) {
      return NextResponse.json(
        { error: `Niveau invalide. Valeurs acceptées : ${BADGE_LEVELS.join(", ")}` },
        { status: 400 }
      );
    }

    const badge = await db.badge.create({
      data: {
        name,
        description,
        level,
        icon: icon || "🏆",
        criteria: criteria || "",
      },
    });

    return NextResponse.json({ badge }, { status: 201 });
  } catch (error) {
    console.error("Admin badges POST error:", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
